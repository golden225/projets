""" cet outil permettra de recuperer des metadonnées a partir d'un pdf  """

# coding:utf8

#import argparse
#import exifread
import  re
import PyPDF2

# une fonctionn pour recuperer les matadonnées

def get_meta(pdf) :
 #recuperer le document pdf  et le stocker dans une variable appele

    ficher = PyPDF2.PdfFileReader(open(pdf,"rb"))

 # appliquer la fonction getdocumentinfo pour recuperer les meta données du documents

    meta_donnée = ficher.getDocumentInfo()

 # afficher les metadonnée

    for i in meta_donnée :
        print("[+]  " +  str(i.replace("/" , ""))   + "    " + meta_donnée[i] )
        if i == "/CreationDate" :
            traitement_localisation = meta_donnée[i]


def get_strings (pdf) :
    with open(pdf,"rb") as file :
        contenu = file.read()
    _re = re.compile("[\S\s]{4,}")
    match = _re.finditer(contenu.decode("utf8","backslashreplace"))
    for i in match :
          print(i.group())



"""

def get_exif(pdf):
    with open(pdf,"rb") as file : 
        contenu = exifread.process_file(file)
    if not exif :
        print(" il n'y a aucune metadonnée de type EXIF ")
    else :
        for tag in exif.keys() :
            print(tag + " " + str(exif[tag]))
            
"""


# affichage du contenue
get_strings("25759684-ANONOPS-The-Press-Release.pdf")


#print(bytes.fromhex("FEFF0041006C0065007800200054006100700061006E0061007200690073").decode("utf16"))

"""
traitement_localisation2 = traitement_localisation.split("+")
traitement_localisation3 = traitement_localisation2[1]
traitement_localisation4 = traitement_localisation3.split("'")
print(traitement_localisation4)"""


"""  # creer des arguments a inserer a l'appel de l'outils en CLI

parser = argparse.ArgumentParser(description=" cracker de mot de passe by manou ")
parser.add_argument("-pdf", dest="file", help=" le chemin du fichier du pdf ", required=False)
args = parser.parse_args()
if args.file :
    get_meta(str(args.file))
"""
